var OEConfEG8ced4f68 = {"WEa62f4ad7d1":{"Custom_Class":"","Apply_Style":false}}
var OEConfSharedEG8ced4f68 = {"Text":{},"Images":{},"Files":{}}
